﻿using SQLite.CodeFirst;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppCodeFirst
{
    /// <summary>
    /// 数据库创建初始化
    /// </summary>
    public class MyInitializer: SqliteDropCreateDatabaseWhenModelChanges<MyDbContext>
    {
        public MyInitializer(DbModelBuilder dbModelbuilder)
            :base(dbModelbuilder)
        {
            
        }
        /// <summary>
        /// 数据库创建初始化数据
        /// </summary>
        /// <param name="context"></param>
        protected override void Seed(MyDbContext context)
        {
            context.Set<Customer>().Add(new Customer() { Id = Guid.NewGuid().ToString(), Name = "FirstCustomer",Age = 23 });
            base.Seed(context);
        }
    }
}

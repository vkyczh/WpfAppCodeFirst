﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity.Core.Metadata.Edm;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Core.Mapping;

namespace WpfAppCodeFirst
{
    public class MyDbContext:DbContext
    {
        public MyDbContext()
            : base("default")
        {

        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //取消表名复数形式
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            //加载配置信息（加载实体类对应的 EntityTypeConfiguration配置）
            //例如Customer 对应的 Maps/CustomerMap
            modelBuilder.Configurations.AddFromAssembly(typeof(MyDbContext).Assembly);
            //数据库初始化
            Database.SetInitializer(new MyInitializer(modelBuilder));
            base.OnModelCreating(modelBuilder);
        }
        /// <summary>
        /// EF 预热
        /// 如创建数据库以及对应的表等
        /// 如果没有执行此动作，则数据库只在访问到数据表时才会建库
        /// </summary>
        public static void PreApplicationStartMethod()
        {
            using (var dbcontext = new MyDbContext())
            {
                var objectContext = ((IObjectContextAdapter)dbcontext).ObjectContext;
                var mappingCollection = (StorageMappingItemCollection)objectContext.MetadataWorkspace.GetItemCollection(DataSpace.CSSpace); mappingCollection.GenerateViews(new List<EdmSchemaError>());
            }  //对程序中定义的所有DbContext逐一进行这个操作
        }
    }
}

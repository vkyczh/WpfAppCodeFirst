﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppCodeFirst.Maps
{
    public class CustomerMap:EntityTypeConfiguration<Customer>
    {
        public CustomerMap()
        {
            HasKey(p => p.Id)
                .Property(p=>p.Name).HasMaxLength(100).IsRequired();
        }
    }
}
